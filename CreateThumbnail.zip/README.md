# lambdaResizeToThumbnail
