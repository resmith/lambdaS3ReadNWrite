rm CreateThumbnail.zip
zip -r CreateThumbnail.zip *
