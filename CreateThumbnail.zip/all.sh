sh zipEm.sh
sh lambdaDelete.sh
sh lambdaCreate.sh
sh lambdaPermissionGrant.sh
sh lambdaPermissionVerify.sh
sh testAsync.sh