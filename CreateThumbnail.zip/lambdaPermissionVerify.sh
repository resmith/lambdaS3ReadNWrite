aws lambda get-policy \
--function-name CreateThumbnail \
--profile adminuser