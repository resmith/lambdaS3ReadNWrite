aws lambda delete-function \
--region us-east-1 \
--function-name lambdaS3ReadNWrite \
--profile adminuser 
