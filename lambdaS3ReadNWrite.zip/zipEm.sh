rm lambdaS3ReadNWrite.zip
zip -r lambdaS3ReadNWrite.zip *
