aws lambda get-policy \
--function-name lambdaS3ReadNWrite \
--profile adminuser