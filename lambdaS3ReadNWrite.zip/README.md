# lambdaResizeToThumbnail
# lambdaS3ReadNWrite
